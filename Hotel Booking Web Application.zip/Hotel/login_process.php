<?php 
	//include('../include/db_con.php');
	require "db_con.php";
	session_start();
		//if (isset($_POST['username'],$_POST['password']))
			//   {
                $username=$_POST['username'];
                $password=$_POST['password'];
  
                   if (empty($username) || empty($password))
                   {
                      $error = 'Hey All fields are required!!';
                    }
                     
					 else {  
					 $login=mysql_query("select * from users where user_name='".$username."' and user_password ='".$password."'");
					 $result=mysql_fetch_array($login);
					 //print_r($result);
					$username=$result['user_name'];
					 
					if($username){
						echo $username;
				 $_SESSION['logged_in']='true';
				 $_SESSION['username']=$username;
					 header('Location:registration.php');
					 //exit();
					 } else {
					 $error='Incorrect details !!';
					 echo $error;
					 }
					       }
		//}
  
  ?>