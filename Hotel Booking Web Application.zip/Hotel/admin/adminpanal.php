<html>
<body>
	
		<body bgcolor="Orange">
		<body bgcolor="">
	  <h1 style="font-family:Algerian"><marquee><font size="40">WELCOME ADMIN...!!!</marquee></h1>
	  <center>Choose option from Below to take action!!!!
	  Create new Booking...click....<a href="../index.php"> Here</a></center>
	  <?php
	  include('../include/db_con.php');
	  $sql="select * from roomdetail ";
	  $row=mysql_query($sql) or die (mysql_error($con));
	 
	  ?>
	  <center>
	  <table border="7">
		<tr>
	 
	  <td><h2><font color="red">S.NO</td><td><h2><font color="red">Username</td><td><h2><font color="red">check in date</td><td><h2><font color="red">check out date</td><td><h2><font color="red">Room Type</td><td><h2><font color="red">No.of Room</td><td><h2><font color="red">Amount</h2></font></td></tr>
	</h1>  </font></center>
	  <?php
		
		  session_start();	
	  while($data=mysql_fetch_array($row))
	  {
		
		
	  
	  ?>
	  <tr>
	  <td><?php echo $data[id]; ?></td>
	  <td><?php echo $data[username]; ?></td>
	  <td><?php echo $data[checkin_date]; ?></td>
	  <td><?php echo $data[checkout_date]; ?></td>
	  <td><?php echo $data[room_type]; ?></td>
	  <td><?php echo $data[no_of_room]; ?></td>
	  <td><?php echo $data[amount]; ?></td>
	  <td><a href="registration.php?id=<?php echo $data[id]; ?>">update</a></td>
	  <td><a href="delete.php?id=<?php echo $data[id]; ?>">delete</a></td>
	  </tr>
	  <?php
	  }
	  
	  
	  ?>
	  </table>
	  
	  </div>
	  <footer>
  <p><marquee><h1 style="font-family:Algerian"><align="center" style="color:black">Submitted By: Imran Khan</h1></marquee></p>
</footer>
</body>
</html>
