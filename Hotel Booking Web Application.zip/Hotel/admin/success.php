<html>
<head>
<style>
body  {
    background-color: #FFA500;
}
</style>


<body>
<div>
<h1>
<h1 style="font-family:Algerian" align="center" style="color:black"><marquee>Your room Updated  successfully...!!!! </marquee></h1></div>

</body>
</html>
