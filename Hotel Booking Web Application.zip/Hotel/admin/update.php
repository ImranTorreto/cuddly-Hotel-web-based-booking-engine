<html>
<head>
<style>
body  {
    background-color: #FFA500;
}
</style>
<style type="text/css">
	#contenar{
		height: 100%;
		width: 100%;
		
	}
	#r{
		margin-top: 5%;
		margin-bottom: 5%;
		margin-right: 5%;
		margin-left: 5%;
		float: center;
		background-color: #b7bcbd;
		
	}

	</style>
	

     
</head>

<body>
<?php
include('../include/db_con.php');
session_start();
if(isset($_POST['sub']))
{
$username=$_POST['username'];
$roomtype=$_POST['field_1'];
$startdate=$_POST['startdate'];
$enddate=$_POST['enddate'];
$room_nos=$_POST['room_nos'];
$amount=$_POST['roomprice'];

$checkroom= "select count(*) from roomdetail where room_type='".$roomtype."' ";
$check=mysql_query($checkroom) or die (mysql_error($con));
$roomcount=mysql_fetch_array($check);
 $checkcount=$roomcount[0];
if($checkcount>=10)
{
?> <script>alert("Sorry Rooms Are not Available :( please try another Option !!");</script>
<?php }
else{
$s1="UPDATE roomdetail set username='".$username."',checkin_date='".$startdate."',checkout_date='".$enddate."',room_type='".$roomtype."',no_of_room='".$room_nos."',amount='".$amount."' where id='".$id."'";
mysql_query($s1) or die (mysql_error($con));
header("location:success.php");
}
}
?>

<div id="contenar">
<?php
if(isset($_GET['id']))
{
$id=$_GET['id'];
$getdata= "select * from roomdetail where id='".$id."' ";
$check1=mysql_query($getdata) or die (mysql_error($con));
$room=mysql_fetch_array($check1);
}


?>
	<div id="r">
	<form action="update.php" method="POST">
	<h1 >
	<align="center" id="h" style="font-family:Algerian" style="color:black"><marquee>Book Room...!!!</marquee></h1>
	<h3> Welcome <?php  echo $room[id];  ?> !!!</h3>
    <table >
		<tr>
		<td>Payment Type:</td>
		<td><input type="radio" name="usertype" id="usertype1" value="cash" />Cash
		<input type="radio" name="usertype" id="usertype2" value="Credit card" />CreditCard
		</td>
		</tr>
          <tr>
            <td width="113">Check in Date</td>
            <td width="215">
              <input name="startdate1" type="date"  value="<?php session_start(); echo $room[checkin_date]; $_SESSION['startdate1']=$room[checkin_date]; ?>" /></td>
          </tr>
          <tr>
            <td>Check out Date</td>
            <td>
              <input name="enddate1" type="date" value="<?php echo $room[checkout_date]?>" onchange='this.form.submit()' /></td>
          </tr>
			
         <tr>
            <td>Room Type </td>
            <td><select name="room_type" id="room_type" size="" >
              <option value="<?php $room[amount];?>"><?php echo $room[room_type];?></option>  
 
<?php 
session_start();
if(isset($_SESSION['startdate1'])){
$paymentDate = $_POST['startdate1'];
$contractDateBegin = '2013-12-20';
$contractDateEnd ='2014-03-25';

$s2="select * from roomtype ";
$s3=mysql_query($s2);



?>
<?php while($catdata=mysql_fetch_array($s3)) { ?> <option value="<?php echo $catdata['room_price']; ?>"><?php echo $catdata['room_type']; ?></option>
<?php } }?>
			
 
           </select></td>
          </tr>
		  <tr>
            <td>Price per Room</td>
            <td>
             <span id="a1"  ></span>&nbsp Rupees INR
           </td>
          </tr>
		   <tr>
            <td>No. of Guest per Room</td>
            <td>
              <input name="guest" type="text " size="10"/></td>
          </tr>
		  <tr>
            <td>No. of Rooms </td>
            <td>
              <input name="room_nos" id="room_nos" type="text " size="10" onChange="gettotal1()" value="<?php echo $room[no_of_room]; ?>"/></td>
          </tr>
		  <tr>
            <td>Total Amount To Pay</td>
            <td>
             <input type="text" name="roomprice" id="total1"  size="10px" readonly=""  value="<?php echo $room[amount];?>"/>
           </td>
          </tr>
		  
          <tr>
            <td colspan="2" align="center">
			<input type="submit" name="sub" value="Pay & Book" /></td>
            </tr>
			
       </table>
		</form>
			
		<script language="javascript" type="text/javascript">
function notEmpty(){

var e = document.getElementById("field_1");
var strUser = e.options[e.selectedIndex].value;
 var strUser=document.getElementById('a1').innerHTML=strUser;




}
notEmpty()
    
    document.getElementById("field_1").onchange = notEmpty;


   function gettotal1(){
      var gender1=document.getElementById('a1').innerHTML;
      var gender2=document.getElementById('room_nos').value;
      var gender3=parseFloat(gender1)* parseFloat(gender2);
			
      document.getElementById('total1').value=gender3;
	
   }
			</script>
 
		
	</div>
</div>
</body>
</html>