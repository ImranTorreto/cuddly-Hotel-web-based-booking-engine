<html>
<head>
<center><h1 style="font-family:Algerian">
<align "center" style="color:red"><u><i>Welcome Admin...!!!</i></u></h1></center>
<style>
body  {
    background-color: #FFA500;
}
</style>
<style type="text/css">
	#contenair{
		height: 90%;
		width: 65%;
		
	}
	#r{
		margin-top: 8%;
		margin-bottom: 5%;
		margin-left: 50%;
		margin-right: -10%;
		height:50%;
		background-color: #b7bcbd;
		
	}
	
	</style>
	

</head>
<body>
<div id="contenair">
	<div id="r" >
	
	<?php 
	include('../include/db_con.php');
	session_start();
		if (isset($_POST['username'],$_POST['password']))
			   {
                $username=$_POST['username'];
                $password=$_POST['password'];
  
                   if (empty($username) || empty($password))
                   {
                      $error = 'Hey All fields are required!!';
                    }
                     
					 else {  
					 $login="select * from users where user_name='".$username."' and user_password ='".$password."'";
					 $result=mysql_query($login);
					 print_r($result);
				
					 
					if(mysql_fetch_array($result)){
				 $_SESSION['logged_in']='true';
				 $_SESSION['username']=$username;
					 header('Location:adminpanal.php');
					 exit();
					 } else {
					 $error='Incorrect details !!';
					 }
					       }
		}
  
  ?>
	<form action="index.php" method="POST">
	<h1>
	<h1 style="font-family:Algerian" align="center" id="h" style="color:black"><marquee>Admin Login Here.!!!! </marquee></h1>
        <table align="center">
		<tr> <?php  if (isset($error)) {?>
           <small style="color:#aa0000;"><?php echo $error; ?>
            <br /> <br />
           <?php } ?> </tr>
          <tr>
            <td width="113">Username:</td>
            <td width="215">
              <input name="username" type="text"  size="40" /></td>
          </tr>
          <tr>
            <td>Password:</td>
            <td>
              <input name="password" type="password"  size="40" /></td>
          </tr>
          <tr>
            <td colspan="2" align="center">
			<input type="submit" name="sub" value="Login" /></td>
            </tr>
			
       </table>
		</form>
		
		
	</div>
</div>
</body>
</html>