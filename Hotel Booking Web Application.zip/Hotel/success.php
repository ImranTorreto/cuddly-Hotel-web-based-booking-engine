<html>
<style> 
div {
    width: 2500px;
    height: 100px;
    position: relative;
    -webkit-animation: mymove 5s infinite; /* Chrome, Safari, Opera */
    -webkit-animation-delay: 2s; /* Chrome, Safari, Opera */
    animation: mymove 5s infinite;
    animation-delay: 2s;
}

/* Chrome, Safari, Opera */
@-webkit-keyframes mymove {
    from {left: 0px;}
    to {left: 200px;}
}

@keyframes mymove {
    from {left: 0px;}
    to {left: 200px;}
}
</style>
<style>
body  {
    background-color: #FFA500;
}
</style>
<body>
<div><h1 style="font-family:Algerian">Your room Booked successfully,You will be contacted soon.</h1></h1></div>
<center><img src="nehu13.jpg" style="width:1300px;height:480px"></center>
<br>
<br>
<center><a href="index.php"><input type="submit" value="Goto Home"></a></center>
</body>
</html>
